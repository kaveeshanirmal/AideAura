<?php

define('ROOT', 'http://localhost/AideAura');
define('ROOT_PATH', dirname(__DIR__, 2));

//database config
define('DBNAME', 'aide_aura');
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', '');
