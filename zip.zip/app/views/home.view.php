<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/home.css">
    <style>
        body{
            height: 100%;
            overflow: hidden;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php include(ROOT_PATH . '/app/views/components/navbar.view.php'); ?>



    <!--Enter Content Here-->
        

    <!-- Footer -->
        <?php include '../app/views/components/footer.view.php'; ?>
</body>
</html>
