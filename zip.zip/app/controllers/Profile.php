<?php

class PROFILE extends Controller
{
    public function index()
    {
        $this->view('profile');
    }
}
