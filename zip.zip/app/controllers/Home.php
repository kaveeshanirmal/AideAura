<?php

class Home extends Controller
{
    public function index($a = '', $b = '', $c = '')
    {
        $this->view('home');
    }

    public function edit($a = '', $b = '', $c = '')
    {
        $this->view('home');
    }

    
}
